#include "Key.h"

Key::Key(char k, string text) {
	keyVal = k;
	textVal = text;
}
